from typing import Literal

from CADETProcess.modelBuilder import BatchElution
from CADETProcess.processModel import ChromatographicColumnBase

from operating_modes.model_parameters import(
    c_feed,
    flow_rate,
)


def setup_process(
    column: ChromatographicColumnBase,
    c_feed=c_feed,
    flow_rate=flow_rate,
    feed_duration=60,
    cycle_time=1000,
) -> BatchElution:
    """Setup batch-elution process."""
    return BatchElution(
        column,
        c_feed=c_feed,
        flow_rate=flow_rate,
        feed_duration=feed_duration,
        cycle_time=cycle_time,
    )


def setup_variables(
    include_cycle_time: bool = True,
    transform: Literal["auto", "linear", "log"] | None = None,
)-> list[dict]:
    """Setup optimization variables."""
    variables = []
    if include_cycle_time:
        variables.append({
            "name": "cycle_time",
            "lb": 10, "ub": 600,
            "transform": transform,
        })
    variables.append({
        "name": "feed_duration.time",
        "lb": 10, "ub": 300,
        "transform": transform,
    })
    return variables


def setup_linear_constraints(
    include_cycle_time: bool = True,
    n_comp: int | None = None,
) -> list[dict]:
    """Setup linear constraints."""
    linear_constraints = []
    if include_cycle_time:
        # Ensure feed duration is shorter than cycle time
        linear_constraints.append({
            "opt_vars": ["feed_duration.time", "cycle_time"],
            "lhs": [1 if not n_comp else n_comp, -1],
            "b": 0.0,
        })
    return linear_constraints


def setup_variable_dependencies(
    include_cycle_time: bool = True,
) -> list[dict]:
    """Setup variable dependencies."""
    variable_dependencies = []
    return variable_dependencies
